<?php
$config['site_name'] = 'My cms site';